

if ! command -v ffmpeg &> /dev/null
then
  echo "Error: ffmpeg is not installed. Please install ffmpeg before running this script."
  exit 1
fi


main_video_file="/Users/dev/Desktop/test_jacket_addon/test_videoone.mp4"
intro_file="/Users/dev/Desktop/test_jacket_addon/intro_thumbnail.jpg"
jacket_file="/Users/dev/Desktop/test_jacket_addon/test_jacket.png"
outro_file="/Users/dev/Desktop/test_jacket_addon/test_videotwo.mp4"
output_folder="/Users/dev/Desktop/test_jacket_addon/Output files"





if [ ! -f "$main_video_file" ]; then
  echo "Error: Main video file does not exist."
  exit 1
fi
if [ ! -f "$jacket_file" ]; then
  echo "Error: Jacket image file does not exist."
  exit 1
fi
if [ ! -f "$outro_file" ]; then
  echo "Error: Endplate file does not exist."
  exit 1
fi
if [ ! -d "$output_folder" ]; then
  echo "Error: Output folder does not exist."
  exit 1
fi
if [ ! -f "$intro_file" ]; then
  echo "Error: Intro file does not exist."
  exit 1
fi


#temp file for the overlayed video
#temp_file1=$(mktemp "${TMPDIR:-/tmp}/temp_file1.XXXXXX.mp4")


base_output_file="${output_folder}/$(basename ${jacket_file%.*})_overlay"
extension=".mp4"
num=0
output_file="${base_output_file}${extension}"

while [ -f "$output_file" ]; do
  num=$((num + 1))
  output_file="${base_output_file}_${num}${extension}"
done


#################     0VERLAYING IMAGE ON VIDEO    #############################


# Get the dimensions of the video
video_width=$(ffprobe -v error -select_streams v:0 -show_entries stream=width -of csv=s=x:p=0 "$main_video_file")
video_height=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of csv=s=x:p=0 "$main_video_file")

# Scale the image to the video dimensions and overlay it on the video
ffmpeg -i "$main_video_file" -i "$jacket_file" -filter_complex "[1:v]scale=$video_width:$video_height[img]; [0:v][img]overlay=0:0" -c:v libx264 -c:a copy "$output_file"
# Success message
echo "Video with overlay created: $output_file"
open "$output_file"

#################     ADDING ENDPLATE    #############################

# Concatenate the overlay video and the endplate video

ffmpeg -i "$output_file" -i "$image_file" -filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[outv][outa]" -map "[outv]" -map "[outa]" "$output_file"
#echo "Final video created: $output_file"

################## ADDING INTRO ###########################
# # Extract the audio from the original video
# ffmpeg -i "$video_file" -vn -ar 44100 -ac 2 -ab 192k -f mp3 sound.mp3

# # Create a video from the image. The duration of this video is 5 seconds.
# ffmpeg -loop 1 -i "$image_file" -c:v libx264 -t 1 -pix_fmt yuv420p10le -y image_video.mp4

# # Concatenate the image video and the main video
# ffmpeg -f concat -safe 0 -i <(echo -e "file '$PWD/image_video.mp4'\nfile '$video_file'") -c copy -y video_without_sound.mp4

# # Add the audio back with delay as of the duration of the thumbnail
# ffmpeg -i video_without_sound.mp4 -itsoffset 1 -i sound.mp3 -c:v copy -c:a aac -strict experimental -map 0:v:0 -map 1:a:0 output.mp4
# # Success message
# echo "Video with thumbnail created: output.mp4"

# # Play the output video
# open output.mp4

############# OPENING THE FINAL OUTPUT FILE #############################

# open "$output_file"