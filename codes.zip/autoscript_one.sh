
#!/bin/bash


select_file() {
    osascript <<EOT
    set theFile to choose file with prompt "Please select your CSV file"
    POSIX path of theFile
EOT
}

# Ask the user to select the CSV file using Finder
input_file=$(select_file)

# Check if the CSV file exists
if [ ! -f "$input_file" ]; then
    echo "Error: The file $input_file does not exist."
    exit 1
fi



# Record the start time
start_time=$(date +%s)

# Function to process videos
process_videos() {
    local main_video_file=$1
    local thumbnail_file=$2
    local overlay_file=$3
    local end_plate_file=$4
    local output_folder=$5

    # Verification
    echo -e "Processing:\nMain video file: $main_video_file\nThumbnail file: $thumbnail_file\nOverlay file: $overlay_file\nEnd plate file: $end_plate_file\nOutput folder: $output_folder"

    # Check for the existence of the files
    for file in "$main_video_file" "$thumbnail_file" "$overlay_file" "$end_plate_file"; do
        if [ ! -f "$file" ]; then
            echo "Error: File $file does not exist."
            return 1
        fi
    done

    # Check for the existence of the output directory
    if [ ! -d "$output_folder" ]; then
        echo "Error: Output directory $output_folder does not exist."
        return 1
    fi

    local jacket_name=$(basename "$overlay_file" | rev | cut -d'.' -f2- | rev)
    local output_file="${output_folder}/${jacket_name}.mp4"

    # Generate thumbnail video and audio concurrently
    ffmpeg -loglevel error -y -hwaccel videotoolbox -loop 1 -t 0.15 -i "$thumbnail_file" -c:v libx264 -pix_fmt yuv420p thumbnail_video.mp4 &
    ffmpeg -loglevel error -y -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 0.15 thumbnail_audio.aac &
    

    if [ ! -f thumbnail_video.mp4 ] || [ ! -f thumbnail_audio.aac ]; then
        echo "Error: Thumbnail video or audio was not created."
        return 1
    fi

    # Concatenate the video and audio to create the thumbnail clip
    ffmpeg -loglevel error -y -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4 &

    if [ ! -f thumbnail_clip.mp4 ]; then
        echo "Error: Thumbnail clip was not created."
        return 1
    fi

    # Extract the width and height of the main video
    main_video_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$main_video_file")
    local main_video_width=$(echo "$main_video_dimensions" | cut -d'x' -f1)
    local main_video_height=$(echo "$main_video_dimensions" | cut -d'x' -f2)

    if [ -z "$main_video_width" ] || [ -z "$main_video_height" ]; then
        echo "Error: Could not extract main video dimensions."
        return 1
    fi

    # Combine all videos into the final output
    ffmpeg -loglevel error -y -hwaccel videotoolbox -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
    [0:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2,setsar=1[end_plate_scaled];
    [1:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2,setsar=1[overlay_scaled];
    [3:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2,setsar=1[thumbnail_scaled];
    [2:v][overlay_scaled] overlay=0:0 [main_with_overlay];
    [thumbnail_scaled][3:a][main_with_overlay][2:a][end_plate_scaled][0:a] concat=n=3:v=1:a=1 [outv][outa]
    " -map "[outv]" -map "[outa]" -c:v h264_videotoolbox -b:v 5000k "$output_file" &

    if [ $? -ne 0 ]; then
        echo "Error: Failed to create final video $output_file."
        return 1
    fi

    echo "Successfully created: $output_file"
    return 0
}

export -f process_videos

# Read the CSV file and process each line
awk -F, 'NR > 1 {
    gsub(/"/, "", $1); gsub(/\r/, "", $1)
    gsub(/"/, "", $2); gsub(/\r/, "", $2)
    gsub(/"/, "", $3); gsub(/\r/, "", $3)
    gsub(/"/, "", $4); gsub(/\r/, "", $4)
    gsub(/"/, "", $5); gsub(/\r/, "", $5)
    system("process_videos \"" $1 "\" \"" $2 "\" \"" $3 "\" \"" $4 "\" \"" $5 "\"")
}' "$input_file" &

spinner $!

# Record the end time
end_time=$(date +%s)

# Calculate and print the execution time
execution_time=$((end_time - start_time))
echo "Total execution time: $execution_time seconds"

osascript -e 'display notification "Your video processing job is done." with title "Job Notification"'

# Determine the overall success or failure of the process
if [ $? -eq 0 ]; then
    osascript -e 'display notification "All videos processed successfully." with title "Success" sound name "Glass"'
else
    osascript -e 'display notification "There were errors in video processing." with title "Failure" sound name "Basso"'
fi
