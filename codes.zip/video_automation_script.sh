#!/bin/bash

# Define your files
main_video_file="/Users/dev/Desktop/test_jacket_addon/test_videoone.mp4"
thumbnail_file="/Users/dev/Desktop/test_jacket_addon/intro_thumbnail.jpg"
overlay_file="/Users/dev/Desktop/test_jacket_addon/test_jacket.png"
end_plate_file="/Users/dev/Desktop/test_jacket_addon/test_videotwo.mp4"

echo "Main video file: $main_video_file"
echo "Overlay file: $overlay_file"
echo "End plate file: $end_plate_file"

# Define the output file
output_file="/Users/dev/Desktop/test_jacket_addon/Output files/final_video.mp4"

#ffmpeg -i "$main_video_file" -i "$overlay_file" -filter_complex "[1:v]scale=$dimensions[overlay_scaled];[0:v][overlay_scaled] overlay=0:0" "$output_file"
# Use FFmpeg's filter_complex to add the thumbnail, overlay, and end plate in one command
# ffmpeg -loop 1 -t 5 -i "$thumbnail_file" -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -i "$main_video_file" -i "$overlay_file" -i "$end_plate_file" -filter_complex "
# [3:v]scale=$dimensions[overlay_scaled];
# [2:v][overlay_scaled] overlay=0:0 [main_with_overlay];
# [0:v][1:a][main_with_overlay][2:a] concat=n=2:v=1:a=1 [thumbnail_and_main];
# [thumbnail_and_main][4:v][4:a] concat=n=2:v=1:a=1 [outv][outa]
# " -map "[outv]" -map "[outa]" "$output_file"
# Use FFmpeg's filter_complex to add the overlay and end plate in one command

#                ----------overlay----------
# ffmpeg -hwaccel auto -i "$main_video_file" -f lavfi -i anullsrc -i "$overlay_file"  -filter_complex "
# [2:v]scale=-1:480[overlay_scaled];
# [0:v][overlay_scaled] overlay=0:0 [main_with_overlay];
# " -map "[main_with_overlay]" "$output_file"

#                ----------overlay + endplate----------
# Use FFmpeg's filter_complex to add the overlay and end plate in one command


# success
# ffmpeg -hwaccel videotoolbox -i "$main_video_file" -f lavfi -i anullsrc -i "$overlay_file" -i "$end_plate_file" -filter_complex "
# [2:v]scale=-1:480[overlay_scaled];
# [0:v][overlay_scaled] overlay=0:0 [main_with_overlay];
# [main_with_overlay][0:a] [3:v][3:a] concat=n=2:v=1:a=1 [outv][outa]
# " -map "[outv]" -map "[outa]" "$output_file"

# # Open the output file
# open "$output_file"

# success
# Create a 5-second video from the thumbnail image
ffmpeg -hwaccel videotoolbox -loop 1 -t 5 -i "$thumbnail_file" -vf "scale=$dimensions" -c:v libx264 -pix_fmt yuv420p thumbnail_video.mp4

# Create a 5-second silent audio track
ffmpeg -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 5 thumbnail_audio.aac

# Concatenate the video and audio to create the thumbnail clip
ffmpeg -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4

# Process the main video file

# Extract the width and height of the jacket video
jacket_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=p=0 "$overlay_file")

if [ -z "$jacket_dimensions" ]; then
    echo "Could not extract jacket dimensions. Please check the jacket file path."
    exit 1
fi

jacket_width=$(echo $jacket_dimensions | cut -d',' -f1)
jacket_height=$(echo $jacket_dimensions | cut -d',' -f2)

if [ -z "$jacket_width" ] || [ -z "$jacket_height" ]; then
    echo "Could not extract jacket width and/or height."
    exit 1
fi

# Process the main video file
# Process the main video file
ffmpeg -hwaccel videotoolbox -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
[1:v]scale=$jacket_width:$jacket_height:force_original_aspect_ratio=decrease,pad=$jacket_width:$jacket_height:(ow-iw)/2:(oh-ih)/2[overlay_scaled];
[2:v][overlay_scaled] overlay=0:0 [main_with_overlay];
[main_with_overlay][2:a] [3:v][3:a] concat=n=2:v=1:a=1 [main_and_thumbnail_v][main_and_thumbnail_a];
[0:v][main_and_thumbnail_v] concat=n=2:v=1:a=0 [outv];
[0:a][main_and_thumbnail_a] concat=n=2:v=0:a=1 [outa]
" -map "[outv]" -map "[outa]" -c:v h264_videotoolbox -b:v 5000k "$output_file"
# Open the output file
open "$output_file"
