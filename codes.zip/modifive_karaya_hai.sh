#paths
video_file="/Users/dev/Downloads/kuchinda 01@.mp4"
image_file="/Users/dev/Downloads/bbsr palasuni issue.jpeg"
jacket="/Users/dev/Desktop/test_jacket_addon/86_Video_Jacket.png"
endplate_file="/Users/dev/Downloads/s218f8vzwdn61.jpg"
destination_file="/Users/dev/Desktop/test_jacket_addon/Output files"


#check availability of files
if [ ! -f "$video_file" ]; then
    echo "Video file does not exist."
    exit 1
fi

if [ ! -f "$jacket" ]; then
    echo "Jacket folder does not exist."
    exit 1
fi

if [ ! -f "$endplate_file" ]; then
    echo "Endplate folder does not exist."
    exit 1
fi

if [ ! -d "$destination_folder" ]; then
    echo "Destination folder does not exist, creating it now..."
    mkdir -p "$destination_folder"
fi
   
 # Output video file name
output_video="$destination_folder/${jacket%.*}_video_with.mp4"

   
#get the jacket dimensions
jacket_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=p=0 "$jacket")
    jacket_width=$(echo $jacket_dimensions | cut -d',' -f1)
    jacket_height=$(echo $jacket_dimensions | cut -d',' -f2)


# Verify dimensions are retrieved
if [ -z "$jacket_width" ] || [ -z "$jacket_height" ]; then
    echo "Failed to retrieve jacket dimensions for $jacket."
    exit 1
fi

ffmpeg -i "$video" -i "$jacket" -filter_complex "[0:v]scale=$jacket_width:$jacket_height:force_original_aspect_ratio=decrease,pad=$jacket_width:$jacket_height:(ow-iw)/2:(oh-ih)/2,overlay=0:0" -c:v h264_videotoolbox -b:v 5000k "$output_video"
echo "Created $output_video with $jacket overlay."