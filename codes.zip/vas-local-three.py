import os
import time
import tempfile
import shutil
import subprocess
import logging
from io import BytesIO
from multiprocessing import Pool
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s:%(message)s')

# Google Sheets and Drive API setup
SERVICE_ACCOUNT_FILE = "/Users/debasishsahu/Desktop/py_env/future-env-424713-g4-3c7f8be744ec.json"
SPREADSHEET_ID = "1SxFmpvISoUZm6zEae1n5WjCxPc57qCxi4xuKJoxmAUU"
SCOPES = ['https://www.googleapis.com/auth/drive', 'https://www.googleapis.com/auth/spreadsheets.readonly']

# Load credentials
creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# Build the service
sheets_service = build('sheets', 'v4', credentials=creds)
drive_service = build('drive', 'v3', credentials=creds)

def get_sheet_data(spreadsheet_id, range_name):
    try:
        sheet = sheets_service.spreadsheets()
        result = sheet.values().get(spreadsheetId=spreadsheet_id, range=range_name).execute()
        values = result.get('values', [])
        logging.info("Fetched data from Google Sheets")
        return values
    except Exception as e:
        logging.error(f"Failed to fetch data from Google Sheets: {e}")
        raise

def upload_file_to_drive(file_path, drive_folder_id):
    try:
        file_metadata = {
            'name': os.path.basename(file_path),
            'parents': [drive_folder_id]
        }
        media = MediaIoBaseUpload(open(file_path, 'rb'), mimetype='video/mp4')
        file = drive_service.files().create(body=file_metadata, media_body=media, fields='id').execute()
        logging.info(f"Uploaded file {file_path} to folder {drive_folder_id}")
        return file.get('id')
    except Exception as e:
        logging.error(f"Failed to upload file {file_path}: {e}")
        raise

def process_videos(params):
    main_video_file, thumbnail_file, overlay_file, end_plate_file, output_folder, drive_folder_id = params
    try:
        logging.info(f"Processing: Main video: {main_video_file}, Thumbnail: {thumbnail_file}, Overlay: {overlay_file}, End plate: {end_plate_file}")

        jacket_name = os.path.splitext(os.path.basename(overlay_file))[0]
        output_file = os.path.join(output_folder, f"{jacket_name}.mp4")

        file_type = subprocess.check_output(['file', '--mime-type', '-b', thumbnail_file]).decode().strip()
        if "video" in file_type:
            thumbnail_clip = thumbnail_file
        elif "image" in file_type:
            # Generating thumbnail video and audio
            subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-hwaccel', 'videotoolbox', '-loop', '1', '-t', '0.15', '-i', thumbnail_file, '-c:v', 'h264_videotoolbox', '-pix_fmt', 'yuv420p', 'thumbnail_video.mp4'])
            subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-hwaccel', 'videotoolbox', '-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100', '-t', '0.15', 'thumbnail_audio.aac'])
            if not (os.path.isfile('thumbnail_video.mp4') and os.path.isfile('thumbnail_audio.aac')):
                logging.error("Failed to create thumbnail video or audio.")
                return 1

            # Concatenate the video and audio to create the thumbnail clip
            subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-hwaccel', 'videotoolbox', '-i', 'thumbnail_video.mp4', '-i', 'thumbnail_audio.aac', '-c:v', 'copy', '-c:a', 'aac', 'thumbnail_clip.mp4'])
            if not os.path.isfile('thumbnail_clip.mp4'):
                logging.error("Failed to create thumbnail clip.")
                return 1

            thumbnail_clip = 'thumbnail_clip.mp4'
        else:
            logging.error(f"Unsupported file type for thumbnail clip: {thumbnail_file}")
            return 1

        overlay_dimensions = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=s=x:p=0', overlay_file]).decode().strip()
        overlay_width, overlay_height = overlay_dimensions.split('x')

        result = subprocess.run([
            'ffmpeg', '-y', '-hwaccel', 'videotoolbox',
            '-i', end_plate_file, '-i', overlay_file, '-i', main_video_file, '-i', thumbnail_clip,
            '-filter_complex', f"""
            [0:v]scale=w={overlay_width}:h={overlay_height}:force_original_aspect_ratio=decrease,pad={overlay_width}:{overlay_height}:(ow-iw)/2:(oh-ih)/2:black,setsar=1[end_plate_scaled];
            [2:v]scale=w={overlay_width}:h={overlay_height}:force_original_aspect_ratio=decrease,pad={overlay_width}:{overlay_height}:(ow-iw)/2:(oh-ih)/2:black,setsar=1[main_scaled];
            [3:v]scale=w={overlay_width}:h={overlay_height}:force_original_aspect_ratio=decrease,pad={overlay_width}:{overlay_height}:(ow-iw)/2:(oh-ih)/2:black,setsar=1[thumbnail_scaled];
            [main_scaled][1:v]overlay=0:0[main_with_overlay];
            [thumbnail_scaled][3:a][main_with_overlay][2:a][end_plate_scaled][0:a]concat=n=3:v=1:a=1[outv][outa]
            """, '-map', '[outv]', '-map', '[outa]', '-c:v', 'h264_videotoolbox', '-b:v', '5000k', output_file
        ])

        if result.returncode != 0:
            logging.error(f"Failed to create final video: {output_file}")
            return 1

        logging.info(f"Successfully created: {output_file}")

        # Upload the video to Google Drive
        upload_file_to_drive(output_file, drive_folder_id)

        return 0
    except Exception as e:
        logging.error(f"Error processing videos: {e}")
        return 1
    # finally:
        # # Clean up temporary files
        # for file in [main_video_file, thumbnail_file, overlay_file, end_plate_file, 'thumbnail_clip.mp4', 'thumbnail_video.mp4', 'thumbnail_audio.aac']:
        #     try:
        #         if os.path.exists(file):
        #             os.remove(file)
        #     except Exception as e:
        #         logging.error(f"Failed to clean up file {file}: {e}")

def main():
    range_name = 'Sheet1!A1:E'  # Adjust the range according to your sheet layout

    try:
        data = get_sheet_data(SPREADSHEET_ID, range_name)
    except Exception as e:
        logging.error(f"Failed to get sheet data: {e}")
        return

    if not data:
        logging.error("No data found in the Google Sheet.")
        return

    header = data[0]
    rows = data[1:]

    start_time = time.time()

    params = []
    for row in rows:
        main_video_path, thumbnail_path, overlay_path, end_plate_path, drive_folder_id = row[:5]
        tmp_dir = "/Users/debasishsahu/Documents/test"
        main_video_file = os.path.join(tmp_dir, os.path.basename(main_video_path))
        thumbnail_file = os.path.join(tmp_dir, os.path.basename(thumbnail_path))
        overlay_file = os.path.join(tmp_dir, os.path.basename(overlay_path))
        end_plate_file = os.path.join(tmp_dir, os.path.basename(end_plate_path))

        try:
            shutil.copy(main_video_path, main_video_file)
            shutil.copy(thumbnail_path, thumbnail_file)
            shutil.copy(overlay_path, overlay_file)
            shutil.copy(end_plate_path, end_plate_file)
        except Exception as e:
            logging.error(f"Failed to copy files: {e}")
            # shutil.rmtree(tmp_dir)
            continue

        params.append((main_video_file, thumbnail_file, overlay_file, end_plate_file, tmp_dir, drive_folder_id))

    with Pool(processes=4) as pool:
        pool.map(process_videos, params)

    end_time = time.time()
    execution_time = int(end_time - start_time)
    logging.info(f"Total execution time: {execution_time} seconds")

if __name__ == "__main__":
    main()
