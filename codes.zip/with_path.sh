#!/bin/bash

# Ensure ffmpeg is in the PATH
export PATH="/usr/local/bin:/opt/homebrew/bin:$PATH"

# Function to process videos
process_videos () {
    local main_video_file=$1 
    local thumbnail_file=$2 
    local overlay_file=$3 
    local end_plate_file=$4 
    local output_folder=$5 

    # Check if ffmpeg is available
    if ! command -v ffmpeg >/dev/null 2>&1; then
        echo -e "\n\n\033[0;31mError:\033[0m ffmpeg is not accessible."
        return 1
    fi

    echo -e "\n\nProcessing:\nMain video file: $main_video_file\nThumbnail file: $thumbnail_file\nOverlay file: $overlay_file\nEnd plate file: $end_plate_file\nOutput folder: $output_folder"
    
    for file in "$main_video_file" "$thumbnail_file" "$overlay_file" "$end_plate_file"
    do
        if [ ! -f "$file" ]; then
            echo -e "\n\n\033[0;31m(Skipping)Error:\033[0m File $file does not exist."
            return 1
        fi
    done

    if [ ! -d "$output_folder" ]; then
        echo -e "\n\n\033[0;31m(Skipping)Error:\033[0m Output directory does not exist."
        return 1
    fi

    local jacket_name=$(basename "$overlay_file" | rev | cut -d'.' -f2- | rev) 
    local output_file="${output_folder}/${jacket_name}.mp4" 
    file_type=$(file --mime-type -b "$thumbnail_file") 

    if [[ $file_type == video/* ]]; then
        cp "$thumbnail_file" thumbnail_clip.mp4
    elif [[ $file_type == image/* ]]; then
        ffmpeg -y -loglevel error -hwaccel videotoolbox -loop 1 -t 0.15 -i "$thumbnail_file" -c:v h264_videotoolbox -pix_fmt yuv420p thumbnail_video.mp4
        ffmpeg -y -loglevel error -hwaccel videotoolbox -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 0.15 thumbnail_audio.aac
        if [ ! -f thumbnail_video.mp4 ] || [ ! -f thumbnail_audio.aac ]; then
            echo -e "\n\n\033[0;31m(Failed)Error:\033[0m Thumbnail video or audio was not created."
            return 1
        fi
        ffmpeg -loglevel error -y -hwaccel videotoolbox -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4
        if [ ! -f thumbnail_clip.mp4 ]; then
            echo -e "\n\n\033[0;31m(Failed)Error:\033[0m Thumbnail clip was not created."
            return 1
        fi
    else
        echo -e "\n\n\033[0;31mError:\033[0m Unsupported file type for thumbnail clip."
        return 1
    fi

    overlay_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$overlay_file") 
    local overlay_width=$(echo "$overlay_dimensions" | cut -d'x' -f1) 
    local overlay_height=$(echo "$overlay_dimensions" | cut -d'x' -f2) 
    if [ -z "$overlay_width" ] || [ -z "$overlay_height" ]; then
        echo -e "\n\n\033[0;31mError:\033[0m Could not extract overlay jacket dimensions."
        return 1
    fi

    frame_rate=$(ffprobe -v error -select_streams v -of default=noprint_wrappers=1:nokey=1 -show_entries stream=r_frame_rate "$main_video_file") 
    if [ -z "$frame_rate" ]; then
        echo -e "\n\n\033[0;31mError:\033[0m Could not extract main video frame rate."
        return 1
    fi

    ffmpeg -y -loglevel error -hwaccel videotoolbox -r "$frame_rate" -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
    [0:v]scale=w=$overlay_width:h=$overlay_height:force_original_aspect_ratio=decrease,pad=$overlay_width:$overlay_height:(ow-iw)/2:(oh-ih)/2:black,setsar=1[end_plate_scaled];
    [2:v]scale=w=$overlay_width:h=$overlay_height:force_original_aspect_ratio=decrease,pad=$overlay_width:$overlay_height:(ow-iw)/2:(oh-ih)/2:black,setsar=1[main_scaled];
    [3:v]scale=w=$overlay_width:h=$overlay_height:force_original_aspect_ratio=decrease,pad=$overlay_width:$overlay_height:(ow-iw)/2:(oh-ih)/2:black,setsar=1[thumbnail_scaled];
    [main_scaled][1:v] overlay=0:0 [main_with_overlay];
    [thumbnail_scaled][3:a][main_with_overlay][2:a][end_plate_scaled][0:a] concat=n=3:v=1:a=1 [outv][outa]
    " -map "[outv]" -map "[outa]" -c:v hevc_videotoolbox -b:v 18000k "$output_file"
    
    if [ $? -ne 0 ]; then
        echo -e "\n\n\033[0;31m[✗] Failed to create final video:\033[0m $output_file"
        return 1
    fi
    
    echo -e "\n\n\033[0;32m[✓] Successfully created:\033[0m $output_file"
    return 0
}

# Example call to the function (replace with actual parameters)
process_videos "main_video.mp4" "thumbnail.jpg" "overlay.png" "end_plate.mp4" "output_folder"
