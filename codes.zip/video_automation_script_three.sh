# Record the start time
start_time=$(date +%s)

# Your script starts here
# Define your files
main_video_file="/Users/dev/Desktop/test_jacket_addon/test_videoone.mp4"
thumbnail_file="/Users/dev/Desktop/test_jacket_addon/intro_thumbnail.jpg"
overlay_file="/Users/dev/Desktop/test_jacket_addon/test_jacket.png"
end_plate_file="/Users/dev/Desktop/test_jacket_addon/test_videotwo.mp4"

echo "Main video file: $main_video_file"
echo "Overlay file: $overlay_file"
echo "End plate file: $end_plate_file"

# Define the output file
output_file="/Users/dev/Desktop/test_jacket_addon/Output files/final_video.mp4"

# Define the commands to create the thumbnail video and the silent audio track
cmd1="ffmpeg -y -hwaccel videotoolbox -loop 1 -t 5 -i "$thumbnail_file" -vf "scale=$dimensions" -c:v libx264 -pix_fmt yuv420p thumbnail_video.mp4"
cmd2="ffmpeg -y -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 5 thumbnail_audio.aac && ffmpeg -y -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4"

# Run the commands in parallel
echo "$cmd1" | parallel &
echo "$cmd2" | parallel &

# Wait for all background jobs to finish
wait

# Concatenate the video and audio to create the thumbnail clip
ffmpeg -y -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4

# Extract the width and height of the jacket video


main_video_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$main_video_file")

main_video_width=$(echo $main_video_dimensions | cut -d'x' -f1)
main_video_height=$(echo $main_video_dimensions | cut -d'x' -f2)

if [ -z "$main_video_width" ] || [ -z "$main_video_height" ]; then
    echo "Could not extract main video width and/or height."
    exit 1
fi

# padding the end plate, overlay, and thumbnail clip
# ffmpeg -y -hwaccel videotoolbox -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
# [0:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2[end_plate_scaled];
# [1:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2[overlay_scaled];
# [3:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2[thumbnail_scaled];
# [2:v][overlay_scaled] overlay=0:0 [main_with_overlay];
# [main_with_overlay][2:a] [thumbnail_scaled][3:a] concat=n=2:v=1:a=1 [main_and_thumbnail_v][main_and_thumbnail_a];
# [end_plate_scaled][main_and_thumbnail_v] concat=n=2:v=1:a=0 [outv];
# [0:a][main_and_thumbnail_a] concat=n=2:v=0:a=1 [outa]
# " -map "[outv]" -map "[outa]" -c:v h264_videotoolbox -b:v 5000k "$output_file"

# # Open the output file
# open "$output_file"

ffmpeg -y -hwaccel videotoolbox -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
[0:v]scale=$main_video_width:$main_video_height[end_plate_scaled];
[1:v]scale=$main_video_width:$main_video_height[overlay_scaled];
[3:v]scale=$main_video_width:$main_video_height[thumbnail_scaled];
[2:v][overlay_scaled] overlay=0:0 [main_with_overlay];
[thumbnail_scaled][3:a] [main_with_overlay][2:a] [end_plate_scaled][0:a] concat=n=3:v=1:a=1 [outv][outa]
" -map "[outv]" -map "[outa]" -c:v h264_videotoolbox -b:v 5000k "$output_file"

# Open the output file
open "$output_file"


# Record the end time
end_time=$(date +%s)

# Calculate and print the execution time
execution_time=$((end_time - start_time))
echo "Total execution time: $execution_time seconds"