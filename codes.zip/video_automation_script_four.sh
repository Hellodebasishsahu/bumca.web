#!/bin/bash

# Record the start time
start_time=$(date +%s)

# Define a function to process the videos
process_videos() {
    local main_video_file=$1
    local thumbnail_file=$2
    local overlay_file=$3
    local end_plate_file=$4
    local output_folder=$5

    echo "Processing: $main_video_file, $thumbnail_file, $overlay_file, $end_plate_file, $output_folder"

    # Check for the existence of the files
    if [ ! -f "$main_video_file" ] || [ ! -f "$thumbnail_file" ] || [ ! -f "$overlay_file" ] || [ ! -f "$end_plate_file" ]; then
        echo "Error: One or more input files do not exist."
        return 1
    fi

    # Check for the existence of the output directory
    if [ ! -d "$output_folder" ]; then
        echo "Error: Output directory does not exist."
        return 1
    fi

    local jacket_name=$(basename "$overlay_file" .png)
    local output_file="${output_folder}/${jacket_name}.mp4"

    # Generate thumbnail video and audio concurrently
    ffmpeg -y -hwaccel videotoolbox -loop 1 -t 5 -i "$thumbnail_file" -vf "scale=1920:1080" -c:v libx264 -pix_fmt yuv420p thumbnail_video.mp4
    ffmpeg -y -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 5 thumbnail_audio.aac

    if [ ! -f thumbnail_video.mp4 ] || [ ! -f thumbnail_audio.aac ]; then
        echo "Error: Thumbnail video or audio was not created."
        return 1
    fi

    # Concatenate the video and audio to create the thumbnail clip
    ffmpeg -y -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4

    if [ ! -f thumbnail_clip.mp4 ]; then
        echo "Error: Thumbnail clip was not created."
        return 1
    fi

    # Extract the width and height of the main video
    local main_video_dimensions
    main_video_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$main_video_file")
    local main_video_width=$(echo "$main_video_dimensions" | cut -d'x' -f1)
    local main_video_height=$(echo "$main_video_dimensions" | cut -d'x' -f2)

    if [ -z "$main_video_width" ] || [ -z "$main_video_height" ]; then
        echo "Error: Could not extract main video dimensions."
        return 1
    fi

    # Combine all videos into the final output
    ffmpeg -y -hwaccel videotoolbox -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
    [0:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2,setsar=1[end_plate_scaled];
    [1:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2,setsar=1[overlay_scaled];
    [3:v]scale=$main_video_width:$main_video_height:force_original_aspect_ratio=decrease,pad=$main_video_width:$main_video_height:(ow-iw)/2:(oh-ih)/2,setsar=1[thumbnail_scaled];
    [2:v][overlay_scaled] overlay=0:0 [main_with_overlay];
    [thumbnail_scaled][3:a][main_with_overlay][2:a][end_plate_scaled][0:a] concat=n=3:v=1:a=1 [outv][outa]
    " -map "[outv]" -map "[outa]" -c:v h264_videotoolbox -b:v 5000k "$output_file"

    if [ $? -ne 0 ]; then
        echo "Error: Failed to create final video $output_file."
        return 1
    fi

    echo "Successfully created: $output_file"
    return 0
}

export -f process_videos

# Read the CSV file and process each line
input_file="/Users/debasishsahu/Downloads/Video_automation_test.csv"
awk -F, 'NR > 1 {
    gsub(/"/, "", $1); gsub(/\r/, "", $1)
    gsub(/"/, "", $2); gsub(/\r/, "", $2)
    gsub(/"/, "", $3); gsub(/\r/, "", $3)
    gsub(/"/, "", $4); gsub(/\r/, "", $4)
    gsub(/"/, "", $5); gsub(/\r/, "", $5)
    system("process_videos \"" $1 "\" \"" $2 "\" \"" $3 "\" \"" $4 "\" \"" $5 "\"")
}' "$input_file"

#     # Call the process_videos function
#     process_videos "$main_video_file" "$thumbnail_file" "$overlay_file" "$end_plate_file" "$output_folder"
# done

# Record the end time
end_time=$(date +%s)

# Calculate and print the execution time
execution_time=$((end_time - start_time))
echo "Total execution time: $execution_time seconds"
