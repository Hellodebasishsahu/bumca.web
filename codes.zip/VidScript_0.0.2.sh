#!/bin/bash

select_file() {
    osascript <<EOT
    set theFile to choose file with prompt "Please select your CSV file"
    POSIX path of theFile
EOT
}

# Ask the user to select the CSV file using Finder
input_file=$(select_file)

# Record the start time
start_time=$(date +%s)

# Function starts here
process_videos() {
    local main_video_file=$1
    local thumbnail_file=$2
    local overlay_file=$3
    local end_plate_file=$4
    local output_folder=$5

    # Verification
    echo "\n\nProcessing:\nMain video file: $main_video_file\nThumbnail file: $thumbnail_file\nOverlay file: $overlay_file\nEnd plate file: $end_plate_file\nOutput folder: $output_folder"

    # Check for the existence of the files
for file in "$main_video_file" "$thumbnail_file" "$overlay_file" "$end_plate_file"; do
    if [ ! -f "$file" ]; then
            echo "\n\n\033[0;31m(Skipping)Error:\033[0m File $file does not exist."
        return 1
    fi
done

    # Check for the existence of the output directory
    if [ ! -d "$output_folder" ]; then
            echo "\n\n\033[0;31m(Skipping)Error:\033[0m Output directory does not exist."
        return 1
    fi

    # Naming the output file
    local jacket_name=$(basename "$overlay_file" | rev | cut -d'.' -f2- | rev)
    local output_file="${output_folder}/${jacket_name}.mp4"


file_type=$(file --mime-type -b "$thumbnail_file")
    if [[ $file_type == video/* ]]; then
        cp "$thumbnail_file" thumbnail_clip.mp4

    elif [[ $file_type == image/* ]]; then


# Generating thumbnail video and audio 
ffmpeg  -y -loglevel error -hwaccel videotoolbox -loop 1 -t 0.15 -i "$thumbnail_file" -c:v h264_videotoolbox -pix_fmt yuv420p thumbnail_video.mp4
ffmpeg  -y -loglevel error -hwaccel videotoolbox -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -t 0.15 thumbnail_audio.aac
    if [ ! -f thumbnail_video.mp4 ] || [ ! -f thumbnail_audio.aac ]; then
            echo "\n\n\033[0;31m(Failed)Error:\033[0m Thumbnail video or audio was not created."
        return 1
    fi

    # Concatenate the video and audio to create the thumbnail clip
ffmpeg -loglevel error -y -hwaccel videotoolbox -i thumbnail_video.mp4 -i thumbnail_audio.aac -c:v copy -c:a aac thumbnail_clip.mp4
    if [ ! -f thumbnail_clip.mp4 ]; then
            echo "\n\n\033[0;31m(Failed)Error:\033[0m Thumbnail clip was not created."
        return 1
    fi

else
        echo "\n\n\033[0;31mError:\033[0m Unsupported file type for thumbnail clip."
    return 1
fi


    # Extract the width and height of the overlay jacket
    overlay_dimensions=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$overlay_file")
        local overlay_width=$(echo "$overlay_dimensions" | cut -d'x' -f1)
        local overlay_height=$(echo "$overlay_dimensions" | cut -d'x' -f2)

    if [ -z "$overlay_width" ] || [ -z "$overlay_height" ]; then
            echo "\n\n\033[0;31mError:\033[0m Could not extract overlay jacket dimensions."
        return 1
    fi
 
 # Extract the frame rate of the main video
    frame_rate=$(ffprobe -v error -select_streams v -of default=noprint_wrappers=1:nokey=1 -show_entries stream=r_frame_rate "$main_video_file")
        
        if [ -z "$frame_rate" ]; then
                echo "\n\n\033[0;31mError:\033[0m Could not extract main video frame rate."
            return 1
        fi

    # Combine all videos into the final output
    ffmpeg  -y -loglevel error -hwaccel videotoolbox -r "$frame_rate" -i "$end_plate_file" -i "$overlay_file" -i "$main_video_file" -i thumbnail_clip.mp4 -filter_complex "
    [0:v]scale=w=$overlay_width:h=$overlay_height:force_original_aspect_ratio=decrease,pad=$overlay_width:$overlay_height:(ow-iw)/2:(oh-ih)/2:black,setsar=1[end_plate_scaled];
    [2:v]scale=w=$overlay_width:h=$overlay_height:force_original_aspect_ratio=decrease,pad=$overlay_width:$overlay_height:(ow-iw)/2:(oh-ih)/2:black,setsar=1[main_scaled];
    [3:v]scale=w=$overlay_width:h=$overlay_height:force_original_aspect_ratio=decrease,pad=$overlay_width:$overlay_height:(ow-iw)/2:(oh-ih)/2:black,setsar=1[thumbnail_scaled];
    [main_scaled][1:v] overlay=0:0 [main_with_overlay];
    [thumbnail_scaled][3:a][main_with_overlay][2:a][end_plate_scaled][0:a] concat=n=3:v=1:a=1 [outv][outa]
    " -map "[outv]" -map "[outa]" -c:v hevc_videotoolbox -b:v 18000k "$output_file" 
    

    if [ $? -ne 0 ]; then
            echo  "\n\n\033[0;31m[✗] Failed to create final video:\033[0m $output_file"
        return 1
    fi

        echo  "\n\n\033[0;32m[✓] Successfully created:\033[0m $output_file"
    return 0
}

export -f process_videos

# Read the CSV file and process each line
awk -F, 'NR > 1 {
    gsub(/"/, "", $1); gsub(/\r/, "", $1)
    gsub(/"/, "", $2); gsub(/\r/, "", $2)
    gsub(/"/, "", $3); gsub(/\r/, "", $3)
    gsub(/"/, "", $4); gsub(/\r/, "", $4)
    gsub(/"/, "", $5); gsub(/\r/, "", $5)
    system("process_videos \"" $1 "\" \"" $2 "\" \"" $3 "\" \"" $4 "\" \"" $5 "\"")
}' "$input_file"

# Determine the overall success or failure of the process
if [ $? -eq 0 ]; then
    osascript -e 'display notification "All videos processed successfully 👍😎." with title "Success" sound name "Glass"'
else
    osascript -e 'display notification "There were errors in video processing 😭🥺." with title "Failure" sound name "Basso"'
fi
    rm -f thumbnail_video.mp4 thumbnail_audio.aac thumbnail_clip.mp4 

# Record the end time
end_time=$(date +%s)

# Calculate and print the execution time
execution_time=$((end_time - start_time))
echo "Total execution time: $execution_time seconds"